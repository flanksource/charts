{{/*
Expand the name of the chart.
*/}}
{{- define "incident-commander.name" -}}
{{- default .Chart.Name .Values.nameOverride | trunc 63 | trimSuffix "-" }}
{{- end }}


{{- define "incident-commander.fullname" -}}
{{- if .Values.fullnameOverride }}
{{- .Values.fullnameOverride | trunc 63 | trimSuffix "-" }}
{{- else }}
{{- $name := default .Chart.Name .Values.nameOverride }}
{{- if contains $name .Release.Name }}
{{- .Release.Name | trunc 63 | trimSuffix "-" }}
{{- else }}
{{- printf "%s-%s" .Release.Name $name | trunc 63 | trimSuffix "-" }}
{{- end }}
{{- end }}
{{- end }}


{{/*
Create chart name and version as used by the chart label.
*/}}
{{- define "incident-commander.chart" -}}
{{- printf "%s-%s" .Chart.Name .Chart.Version | replace "+" "_" | trunc 63 | trimSuffix "-" }}
{{- end }}

{{/*
Common labels
*/}}
{{- define "incident-commander.labels" -}}
helm.sh/chart: {{ include "incident-commander.chart" . }}
{{ include "incident-commander.selectorLabels" . }}
{{- if .Chart.AppVersion }}
app.kubernetes.io/version: {{ .Chart.AppVersion | quote }}
{{- end }}
app.kubernetes.io/managed-by: {{ .Release.Service }}
{{- end }}

{{/*
Base selector labels shared by incident-commander workloads.
*/}}
{{- define "incident-commander.selectorLabels" -}}
app.kubernetes.io/name: {{ include "incident-commander.name" . }}
app.kubernetes.io/instance: {{ .Release.Name }}
control-plane: incident-commander
{{- end }}

{{/*
Stable selector labels for the main mission-control pods.

This is intentionally a superset of incident-commander.selectorLabels so it can
be used for pod template labels and Service selectors without changing the
immutable Deployment selector on upgrade.
*/}}
{{- define "incident-commander.missionControl.selectorLabels" -}}
{{ include "incident-commander.selectorLabels" . }}
app.kubernetes.io/component: mission-control
{{- end }}

{{- define "incident-commander.extraLabels" -}}
{{- if .Values.global.labels -}}
{{.Values.global.labels | toYaml}}
{{- end }}
{{- end }}

{{- define "postgrest.image" -}}
{{ if .Values.externalPostgrest.imageName }}
{{- .Values.externalPostgrest.imageName -}}
{{- else if eq .Values.global.imageRegistry "public.ecr.aws" -}}
public.ecr.aws/supabase/postgrest
{{- else -}}
docker.io/postgrest/postgrest
{{- end }}
{{- end }}

{{/*
https://github.com/ory/k8s/blob/master/helm/charts/kratos/templates/_helpers.tpl#L103
*/}}

{{/*
Create a secret name which can be overridden.
*/}}
{{- define "kratos-im.secretname" -}}
{{- .Values.kratos.fullnameOverride | trunc 63 | trimSuffix "-" -}}
{{- end -}}

{{/*
Generate the secrets.default value
*/}}
{{- define "kratos-im.secrets.default" -}}
  {{- if (.Values.kratos.kratos.config.secrets).default -}}
    {{- if kindIs "slice" .Values.kratos.kratos.config.secrets.default -}}
      {{- if gt (len .Values.kratos.kratos.config.secrets.default) 1 -}}
        "{{- join "\",\"" .Values.kratos.kratos.config.secrets.default -}}"
      {{- else -}}
        {{- join "" .Values.kratos.kratos.config.secrets.default -}}
      {{- end -}}
    {{- else -}}
      {{- fail "Expected kratos.kratos.config.secrets.default to be a list of strings" -}}
    {{- end -}}
  {{- end -}}
{{- end -}}

{{/*
Generate the secrets.cookie value
*/}}
{{- define "kratos-im.secrets.cookie" -}}
  {{- if (.Values.kratos.kratos.config.secrets).cookie -}}
    {{- if kindIs "slice" .Values.kratos.kratos.config.secrets.cookie -}}
      {{- if gt (len .Values.kratos.kratos.config.secrets.cookie) 1 -}}
        "{{- join "\",\"" .Values.kratos.kratos.config.secrets.cookie -}}"
      {{- else -}}
        {{- join "" .Values.kratos.kratos.config.secrets.cookie -}}
      {{- end -}}
    {{- else -}}
      {{- fail "Expected kratos.config.secrets.cookie to be a list of strings" -}}
    {{- end -}}
  {{- end -}}
{{- end -}}

{{/*
Generate the secrets.cipher value
*/}}
{{- define "kratos-im.secrets.cipher" -}}
  {{- if (.Values.kratos.kratos.config.secrets).cipher -}}
    {{- if kindIs "slice" .Values.kratos.kratos.config.secrets.cipher -}}
      {{- if gt (len .Values.kratos.kratos.config.secrets.cipher) 1 -}}
        "{{- join "\",\"" .Values.kratos.kratos.config.secrets.cipher -}}"
      {{- else -}}
        {{- join "" .Values.kratos.kratos.config.secrets.cipher -}}
      {{- end -}}
    {{- else -}}
      {{- fail "Expected kratos.config.secrets.cipher to be a list of strings" -}}
    {{- end -}}
  {{- end -}}
{{- end -}}

{{- define "incident-commander.artifactstore.name" -}}
{{- printf "%s-artifactstore" (include "incident-commander.fullname" .) | trunc 63 | trimSuffix "-" -}}
{{- end -}}

{{- define "incident-commander.artifactstore.deploymentName" -}}
{{- $fullname := include "incident-commander.fullname" . | trunc 50 | trimSuffix "-" -}}
{{- printf "%s-artifacts" $fullname | trunc 63 | trimSuffix "-" -}}
{{- end -}}

{{- define "incident-commander.artifactstore.pvc" -}}
{{- if .Values.artifactstore.volume.existingClaim -}}
{{- .Values.artifactstore.volume.existingClaim -}}
{{- else -}}
{{- include "incident-commander.artifactstore.name" . -}}
{{- end -}}
{{- end -}}

{{- define "incident-commander.artifactstore.labelName" -}}
artifactstore
{{- end -}}

{{- define "incident-commander.artifactstore.selectorLabels" -}}
app.kubernetes.io/name: {{ include "incident-commander.artifactstore.labelName" . }}
app.kubernetes.io/instance: {{ .Release.Name }}
app.kubernetes.io/component: artifactstore
{{- end -}}

{{- define "incident-commander.artifactstore.labels" -}}
helm.sh/chart: {{ include "incident-commander.chart" . }}
{{ include "incident-commander.artifactstore.selectorLabels" . }}
app.kubernetes.io/part-of: {{ include "incident-commander.name" . }}
{{- if .Chart.AppVersion }}
app.kubernetes.io/version: {{ .Chart.AppVersion | quote }}
{{- end }}
app.kubernetes.io/managed-by: {{ .Release.Service }}
{{- end -}}
